The TAPS simulation coordinate file and sample files are attached inside TAPS-Myosin-V and TAPS-Myosin-VI folder.

The input files for renormalization is attached inside Renormalisation_sample_file folder. It can be executed as "./channelix21vel.exe_xyz < gramicidin.inp > a.log &

The sample input coordinates and input topologies and parameters for Steer molecular dynamics simulations and Umbrella sampling simulations are attached. All the force-filed parameters are included inside the charmm36-jul2022.ff folder.